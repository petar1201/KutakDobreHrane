import { Component } from '@angular/core';

@Component({
  selector: 'app-waiter-statistics-page',
  templateUrl: './waiter-statistics-page.component.html',
  styleUrls: ['./waiter-statistics-page.component.css']
})
export class WaiterStatisticsPageComponent {

}
