
export class RestaurantListItem{
    name: String
    address: String
    contactPerson: String
    type: String
    workingHours: String
    waiters: String
}