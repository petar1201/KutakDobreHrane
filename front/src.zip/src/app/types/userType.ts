enum UserType{
    ADMIN = "ADMIN",
    GUEST = "GUEST",
    WAITER = "WAITER"

}
export default UserType;