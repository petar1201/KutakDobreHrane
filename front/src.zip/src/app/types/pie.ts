export class Pie{
    name: String
    num: Number
}