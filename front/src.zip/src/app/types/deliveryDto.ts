export class DeliveryDto{
    id: Number
    deliveryTime: Number
    status: String
    expectedArrival ?: Number
    restaurantName: String
    dateTime: string
    cart: String
}