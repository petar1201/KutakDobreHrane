enum UserStatus{
    ACTIVE = "ACTIVE",
    WAITING = "WAITING",
    REFUSED = "REFUSED"
}
export default UserStatus;