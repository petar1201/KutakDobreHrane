export class Histogram{
    mon: Number;
    tue: Number;
    wed: Number;
    thu: Number;
    fri: Number;
    sat: Number;
    sun: Number;
}