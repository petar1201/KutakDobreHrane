export class FoodDto {
    id: Number;
    name: String;
    price: Number;
    ingredients: Number;
    photo: String;
    quantity: number;

}