export class ReservationSummary{
    lastDay: Number
    lastWeek: Number
    lastMonth: Number
}