export class CreateReservationRequest {
    idGuest: Number;
    idRestaurant: Number;
    dateTime: String;
    description: String;
    numOfPersons: Number;
}
