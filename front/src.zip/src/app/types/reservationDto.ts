export class ReservationDto{
    id: Number
    description: String
    status: String
    restaurantName: String
    restaurantAddress: String
    numOfPeople: Number
    dateTime: string
    idRes: Number
    restaurantLayout: String
}