enum RestaurantType{
    SERBIAN = "SERBIAN",
    CHINESE = "CHINESE",
    INDIAN = "INDIAN",
    JAPANESE = "JAPANESE",
    ITALIAN = "ITALIAN",
    THAI = "THAI"
}
export default RestaurantType;