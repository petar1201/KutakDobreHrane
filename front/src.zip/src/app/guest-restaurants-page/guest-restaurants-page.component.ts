import { Component } from '@angular/core';

@Component({
  selector: 'app-guest-restaurants-page',
  templateUrl: './guest-restaurants-page.component.html',
  styleUrls: ['./guest-restaurants-page.component.css']
})
export class GuestRestaurantsPageComponent {

}
